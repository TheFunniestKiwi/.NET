﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace Lab_01
{
    public  class HighScore
    {


        public string Name { get; set; }
        public int Trials { get; set; }




    }
}
